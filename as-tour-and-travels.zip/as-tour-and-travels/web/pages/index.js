import BookingWidget from '../components/BookingWidget'
import Footer from '../components/Footer'
import axios from 'axios'

export default function Home() {
  async function handleLead(e) {
    e.preventDefault()
    const form = new FormData(e.target)
    const data = Object.fromEntries(form)
    // send to your Strapi endpoint or to /api/lead
    try {
      await axios.post('/api/lead', data)
      alert('Thank you — we will contact you shortly!')
      e.target.reset()
    } catch (err) {
      console.error(err)
      alert('Something went wrong. You can also WhatsApp us at 8602837299.')
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 bg-white shadow z-40">
        <div className="max-w-6xl mx-auto flex items-center justify-between p-4">
          <h1 className="text-xl font-bold">A S Tour And Travels</h1>
          <div className="flex items-center gap-4">
            <a href="tel:8602837299" className="text-sm">Call: 8602837299</a>
            <a href="https://wa.me/918602837299" target="_blank" rel="noreferrer" className="bg-green-600 text-white px-3 py-2 rounded text-sm">WhatsApp</a>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="relative">
          <div className="bg-cover bg-center h-[420px]" style={{backgroundImage: "url('/hero.jpg')"}}>
            <div className="max-w-6xl mx-auto h-full flex items-center">
              <div className="bg-white/70 p-6 rounded shadow-lg max-w-xl ml-6">
                <h2 className="text-2xl font-bold">Book Flights, Trains, Buses, Cabs & More</h2>
                <p className="mt-2">Fast quotes • Trusted • GST-ready</p>
                <BookingWidget />
              </div>
            </div>
          </div>
        </section>

        <section className="max-w-6xl mx-auto p-6">
          <h3 className="text-xl font-semibold">Quick Quote</h3>
          <form onSubmit={handleLead} className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
            <input name="name" required placeholder="Name" className="p-3 border rounded" />
            <input name="phone" required placeholder="Phone" className="p-3 border rounded" />
            <select name="service" className="p-3 border rounded">
              <option>Flight Ticket</option>
              <option>Railway Ticket</option>
              <option>Bus Ticket</option>
              <option>Cab Booking</option>
              <option>Visa Service</option>
              <option>Passport Assistance</option>
            </select>
            <input name="email" placeholder="Email (optional)" className="p-3 border rounded md:col-span-2" />
            <button className="bg-blue-600 text-white px-4 py-3 rounded">Get Quote</button>
          </form>
        </section>
      </main>

      <Footer />
    </div>
  )
}
