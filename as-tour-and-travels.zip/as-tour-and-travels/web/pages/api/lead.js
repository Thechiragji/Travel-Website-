import axios from 'axios'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const lead = req.body

  try {
    // example: post to Strapi (replace with your Strapi URL & token)
    const STRAPI_URL = process.env.STRAPI_URL
    const STRAPI_TOKEN = process.env.STRAPI_TOKEN
    if (STRAPI_URL && STRAPI_TOKEN) {
      await axios.post(`${STRAPI_URL}/api/leads`, { data: lead }, {
        headers: { Authorization: `Bearer ${STRAPI_TOKEN}` }
      })
    }
    // Fallback: send a notification email (integrate SendGrid / SMTP) — not implemented here
    return res.status(200).json({ ok: true })
  } catch (err) {
    console.error('lead error', err.response?.data || err.message)
    return res.status(500).json({ error: 'failed to save lead' })
  }
}
