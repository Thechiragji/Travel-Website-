export default function BookingWidget() {
  return (
    <div className="mt-4">
      <form className="grid grid-cols-1 md:grid-cols-3 gap-2">
        <input className="p-2 border rounded" placeholder="From (City/Airport)" />
        <input className="p-2 border rounded" placeholder="To (City/Airport)" />
        <div className="flex gap-2">
          <input type="date" className="p-2 border rounded w-full" />
          <button type="button" className="bg-slate-800 text-white px-3 rounded">Search</button>
        </div>
      </form>
      <p className="text-xs mt-2">If rates not available, use Quick Quote form or WhatsApp 8602837299</p>
    </div>
  )
}
