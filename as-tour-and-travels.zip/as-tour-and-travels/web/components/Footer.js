export default function Footer(){
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-6xl mx-auto p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <h4 className="font-bold">A S Tour And Travels</h4>
          <p>GST: (add your GST no.)</p>
        </div>
        <div>
          <h5 className="font-semibold">Contact</h5>
          <p>Phone / WhatsApp: <a href="https://wa.me/918602837299" className="underline">8602837299</a></p>
          <p>Email: <a href="mailto:A.stourandtravels@yahoo.com" className="underline">A.stourandtravels@yahoo.com</a></p>
        </div>
        <div>
          <h5 className="font-semibold">Quick Links</h5>
          <ul className="text-sm">
            <li>Flights</li>
            <li>Trains</li>
            <li>Buses</li>
            <li>Visa & Passport</li>
          </ul>
        </div>
      </div>
      <div className="bg-black/50 text-center p-3 text-xs">© {new Date().getFullYear()} A S Tour And Travels</div>
    </footer>
  )
}
