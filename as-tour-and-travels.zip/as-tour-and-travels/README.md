# A S Tour And Travels — Starter

This repo contains a Next.js + Tailwind static front-end and Strapi content-type schemas for leads & bookings.

## Quick start
1. cd web
2. npm ci
3. npm run dev

## Deploy
- For static: npm run build && npm run export
- Recommended: Deploy on Vercel or Netlify, set STRAPI_URL & STRAPI_TOKEN in env.

Contacts included:
- Phone/WhatsApp: 8602837299
- Email: A.stourandtravels@yahoo.com
